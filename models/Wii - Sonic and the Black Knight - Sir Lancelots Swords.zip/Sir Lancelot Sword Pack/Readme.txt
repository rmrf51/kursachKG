Ripped for The Models Resource by josh98

DAE exported with OPENCOLLADA

Thanks to ItsEasyActually and Random Talking Bush for the script!